
import picture from "./picture.png";
import aquarium1 from "./aquarium1.jpg";
import aurora2 from "./aurora2.jpg";

import seasons from "./seasons.jpg";
import lany from "./lany.png";
import onbended from "./onbended.jpg";
import herewithme from "./herewithme.jpg";
import givemeyour from "./givemeyour.jpg";
import honey from "./honey.jpg";
import always from "./always.jpg";
import mylove from "./mylove.jpg";


import fireworks from "./fireworks.gif";
import mocha from "./mocha.gif";




export {

picture,
aquarium1,
aurora2,
seasons,
mocha,
fireworks,
lany,
onbended,
herewithme,
givemeyour,
honey,
always,
mylove,
};
