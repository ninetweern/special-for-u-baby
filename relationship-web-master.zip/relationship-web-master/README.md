# My React + Vite Project

### Installation
1. Clone the repository

2. Install dependencies:
```bash
npm install
```
3. Start the development server:
```bash
npm run dev
```
4. Open your browser and navigate to http://localhost:5173/ (default Vite dev server URL).


